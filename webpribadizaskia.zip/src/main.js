import './style.css';
//profil
const profil = {
  nama: "Zaskia Yoenda",
  nim: "2505553",
  jurusan: "Pendidikan Ilmu Komputer",
  univ: "UPI Bandung",
  status: "Mahasiswa Pendidikan Ilmu Komputer",
  deskripsi: "Saya seorang mahasiswa Pendidikan Ilmu Komputer UPI yang sedang belajar web development.",
  kontak: {
    phone: "+62 85172170611",
    alamat: "Jln. Gegerkalong",
    email: "zaskiayo@gmail.com",
    instagram: "@yoendas"
  }
};

// keahlian
const skills = [
  { nama: "HTML & CSS", icon: "src/assets/htmlcss.jpg" },
  { nama: "Figma", icon: "src/assets/figma.png" },
  { nama: "C Programming", icon: "src/assets/bahasac.png" },
  { nama: "MySQL", icon: "src/assets/sql.png" },
  { nama: "Canva", icon: "src/canva.jpg" }
];

// Proyek
const projects = [
  {
    id: 1,
    judul: "Si Coding",
    deskripsi: "Media pembelajaran interaktif pemikiran komputasional dan pemrograman C untuk siswa SMA.",
    kategori: "Web App / Edukasi"
  },
  {
    id: 2,
    judul: "Clustering UKM UPI",
    deskripsi: "Penerapan algoritma K-Means clustering untuk analisis perspektif mahasiswa terhadap organisasi kampus.",
    kategori: "Data Science"
  },
  {
    id: 3,
    judul: "Database perpustakaan",
    deskripsi: "Sistem pengelolaan basis data relasional perpustakaan menggunakan phpMyAdmin & XAMPP.",
    kategori: "Database"
  }
];

const renderApp = () => {
  document.querySelector('#app').innerHTML = `
    <!-- Navigasi awal bagian header -->
    <nav>
      <div class="wrapper">
        <div class="logo"><a href="">ZaskiaY</a></div>
        <div class="menu">
          <ul>
            <li><a href="#beranda">Beranda</a></li>
            <li><a href="#tentang-saya">Tentang Saya</a></li>
            <li><a href="#keahlian">Keahlian</a></li>
            <li><a href="#proyek">Proyek</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="wrapper">
      <!-- Section Beranda profil awal -->
      <section id="beranda">
        <img src="src/assets/gambr.jpg" alt="Profil Sticker" />
        <div class="kolom">
          <p class="deskripsi">Hallo, Saya....</p>
          <h2>${profil.nama}</h2>
          <p>NIM : ${profil.nim}</p>
          <p><a href="#tentang-saya" class="tbl-pink">Next</a></p>
        </div>
      </section>

      <!-- Section Tentang Saya -->
      <section id="tentang-saya">
        <div class="kolom">
          <p class="deskripsi">Tentang Saya</p>
          <h2>About Me</h2>
          <p>Saya ${profil.nama}, merupakan mahasiswa dari ${profil.jurusan} di ${profil.univ}</p>
          <p>${profil.deskripsi}</p>
          <p><a href="#keahlian" class="tbl-biru">Next</a></p>
        </div>
        <img src="src/assets/foto.jpeg" alt="About Me Sticker" />
      </section>

      <!-- Section Keahlian skill -->
      <section id="keahlian">
        <div class="kolom">
          <p class="deskripsi">Keahlian</p>
          <h2>Skills</h2>
          <div class="skills-container">
          ${skills.map(skill => `
            <div class="skill-card">
              <img src="${skill.icon}" alt="${skill.nama}" class="skill-icon" />
              <span>${skill.nama}</span>
            </div>
            `).join('')}
          </div>
        </div>
      </section>

      
      <!-- Section proyek  -->
      <section id="proyek">
        <div class="kolom">
          <p class="deskripsi">Karya</p>
          <h2>Proyek Saya</h2>
          <div class="projects-grid">
            ${projects.map(pj => `
              <div class="project-card">
                <span class="project-kategori">${pj.kategori}</span>
                <h3 style="margin: 8px 0; color: var(--text-h);">${pj.judul}</h3>
                <p style="font-size: 14px;">${pj.deskripsi}</p>
              </div>
            `).join('')}
          </div>
        </div>
      </section>
    </div>

    <!-- Section informasi contact  -->
    <div id="contact">
      <div class="wrapper">
        <div class="footer">
          <div class="footer-section">
            <h3>📱 No hp</h3>
            <p>${profil.kontak.phone}</p>
          </div>
          <div class="footer-section">
            <h3>📍Alamat</h3>
            <p>${profil.kontak.alamat}</p>
          </div>
          <div class="footer-section">
            <h3>✉️ Email</h3>
            <p>${profil.kontak.email}</p>
          </div>
          <div class="footer-section">
            <h3>Social Media</h3>
            <p><b>Instagram: </b>${profil.kontak.instagram}</p>
          </div>
        </div>
      </div>
    </div>
  `;
};

renderApp();